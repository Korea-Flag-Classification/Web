from django.apps import AppConfig


class MlsearchConfig(AppConfig):
    name = 'mlsearch'
