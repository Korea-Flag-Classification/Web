from django.urls import path

from .views import CheckImageView


urlpatterns = [
    path("", CheckImageView.as_view(), name="check-image"),
]
