from django.views.generic import FormView
from django import forms
from django.urls import reverse_lazy
from django.http import HttpResponseRedirect
from django.conf import settings

# ml lib
from keras.models import load_model
from PIL import Image
import keras
import tensorflow as tf
import matplotlib.pyplot as plt
import cv2
import os
import numpy as np


class ImageUploadForm(forms.Form):
    image = forms.CharField(
        label='이미지 붙여넣기',
        required=True)


class CheckImageView(FormView):
    form_class = ImageUploadForm
    template_name = 'check-image.html'
    success_url = reverse_lazy('check-image')

    def post(self, request, *args, **kwargs):
        form = self.get_form()
        if form.is_valid():
            return self.form_valid(form)
        else:
            return self.form_invalid(form)

    def get_ml_result(self, image_data):
        is_korea_flag = True
        os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
        model = load_model(settings.ML_MODEL_FILE)
        """
        image = Image.open(file_path).convert('RGB')
        image = image.resize((200,200))
        image = np.array(image)
        image = image.reshape((200,200,3))
        # plt.imshow(image)
        x_test = [image]
        x_test = np.array(x_test)
        x_test = x_test / 255
        pred = model.predict(x_test)
        if pred < 0.5:
            is_korea_flag = True
        else:
            is_korea_flag = False
        """
        return is_korea_flag

    def form_valid(self, form):
        context = self.get_context_data()
        image_data = form.cleaned_data.get('image')
        result = None
        if image_data:
            is_korea_flag = self.get_ml_result(image_data)
            context['result'] = {
                'is_korea_flag': is_korea_flag,
            }
        return self.render_to_response(context)
        
